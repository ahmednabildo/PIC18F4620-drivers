
 /* 
 * File:   diploma.c
 * Author: Ahmed Donia
 *
 * Created on September 27, 2023, 4:33 PM
 */


#include"diploma.h"

seg_t seg=
{
    .seg_pins[SEG_PIN0].port = PORTC_INDEX,
    .seg_pins[SEG_PIN1].port = PORTC_INDEX,
    .seg_pins[SEG_PIN2].port = PORTC_INDEX,
    .seg_pins[SEG_PIN3].port = PORTC_INDEX,
    
    .seg_pins[SEG_PIN0].pin = PIN0,
    .seg_pins[SEG_PIN1].pin = PIN1,
    .seg_pins[SEG_PIN2].pin = PIN2,
    .seg_pins[SEG_PIN3].pin = PIN3,
    
    .seg_pins[SEG_PIN0].direction = OUTPUT,
    .seg_pins[SEG_PIN1].direction = OUTPUT,
    .seg_pins[SEG_PIN2].direction = OUTPUT,
    .seg_pins[SEG_PIN3].direction = OUTPUT,
    
    .seg_pins[SEG_PIN0].logic = LOW,
    .seg_pins[SEG_PIN1].logic = LOW,
    .seg_pins[SEG_PIN2].logic = LOW,
    .seg_pins[SEG_PIN3].logic = LOW,
    
    .seg_type = SEG_COM_CAT
    
    
    
};

pin_config_t pins[2] =
{
    [0].port=PORTD_INDEX,
    [0].pin = PIN2,
    [0].logic = LOW,
    [0].direction = OUTPUT,
    
    [1].port=PORTD_INDEX,
    [1].pin = PIN5,
    [1].logic = LOW,
    [1].direction = OUTPUT,
};


keypad_t keypad_ = 
{
  .keypad_row_pins[0].port = PORTC_INDEX,  
  .keypad_row_pins[1].port = PORTC_INDEX, 
  .keypad_row_pins[2].port = PORTC_INDEX, 
  .keypad_row_pins[3].port = PORTC_INDEX,
  
  .keypad_col_pins[0].port = PORTC_INDEX,  
  .keypad_col_pins[1].port = PORTC_INDEX, 
  .keypad_col_pins[2].port = PORTC_INDEX, 
  .keypad_col_pins[3].port = PORTC_INDEX,
  
  .keypad_row_pins[0].pin = PIN0,  
  .keypad_row_pins[1].pin = PIN1, 
  .keypad_row_pins[2].pin = PIN2, 
  .keypad_row_pins[3].pin = PIN3, 
  
  .keypad_col_pins[0].pin = PIN4,  
  .keypad_col_pins[1].pin = PIN5, 
  .keypad_col_pins[2].pin = PIN6, 
  .keypad_col_pins[3].pin = PIN7, 
  
  .keypad_row_pins[0].direction = OUTPUT,
  .keypad_row_pins[1].direction = OUTPUT,
  .keypad_row_pins[2].direction = OUTPUT,
  .keypad_row_pins[3].direction = OUTPUT,
  
  .keypad_col_pins[0].direction = INPUT,
  .keypad_col_pins[1].direction = INPUT,
  .keypad_col_pins[2].direction = INPUT,
  .keypad_col_pins[3].direction = INPUT,
  
  .keypad_row_pins[0].logic = LOW,
  .keypad_row_pins[1].logic = LOW,
  .keypad_row_pins[2].logic = LOW,
  .keypad_row_pins[3].logic = LOW,
  
  .keypad_col_pins[0].logic = LOW,
  .keypad_col_pins[1].logic = LOW,
  .keypad_col_pins[2].logic = LOW,
  .keypad_col_pins[3].logic = LOW,
};







void app_init(void);
uint8 sec=0,min=0,hour=0;
int main() 
{
    app_init();
    while(1)
    {    
        
        for(uint8 i=0 ;i<50;i++)
        {
            gpio_port_write_logic(PORTD_INDEX, (uint8)(0b11111110));
            gpio_port_write_logic(PORTC_INDEX, (uint8)(hour/10));
            __delay_us(3333);
        
        
            gpio_port_write_logic(PORTD_INDEX, (uint8)(0b11111101));
            gpio_port_write_logic(PORTC_INDEX, (uint8)(hour%10));
            __delay_us(3333);
            gpio_port_write_logic(PORTD_INDEX, (uint8)(0b11110111));
            gpio_port_write_logic(PORTC_INDEX, (uint8)(min/10));
            __delay_us(3333);
        
            gpio_port_write_logic(PORTD_INDEX, (uint8)(0b11101111));
            gpio_port_write_logic(PORTC_INDEX, (uint8)(min%10));
            __delay_us(3333);  
            
            gpio_port_write_logic(PORTD_INDEX, (uint8)(0b10111111));
            gpio_port_write_logic(PORTC_INDEX, (uint8)(sec/10));
            __delay_us(3333);
            
            gpio_port_write_logic(PORTD_INDEX, (uint8)(0b01111111));
            gpio_port_write_logic(PORTC_INDEX, (uint8)(sec%10));
            __delay_us(3333);
           
            }
        sec++;
        if(sec==60)
        {
            min++;
            sec=0;
        }
        if(min==60)
        {
            hour++;
            min=0;
        }
       

        
        //

        
        

        

        
        
    }
    return (0);
}

void app_init(void)
{
    std_ReturnType ret = E_NOT_OK;
    _7_seg_init(&seg);
    gpio_port_direction_initialize(PORTD_INDEX, OUTPUT);
    gpio_port_direction_initialize(PORTC_INDEX, OUTPUT);
    
}



