/* 
 * File:   diploma.h
 * Author: Ahmed Donia
 *
 * Created on September 27, 2023, 5:07 PM
 */

#ifndef DIPLOMA_H
#define	DIPLOMA_H




/* SECTION : Includes*/
#include"ECU_layer/LED/ecu_led.h"

#include "ECU_layer/BUTTON/ecu_button.h" 
#include"ECU_layer/RELAY/ecu_relay.h"
#include"ECU_layer/DC_MOTOR/ecu_dc_motor.h"
#include"ECU_layer/7_SEGMENT/ecu_7_seg.h"
#include"ECU_layer/KEYPAD/ecu_keypad.h"
#include"ECU_layer/Chr_LCD/ecu_chr_lcd.h"

/* SECTION : MACRO_Declaration*/


/* SECTION : MACRO_function_Declaration*/

/* SECTION : DATA_TYPES_DECLARATION*/


/* SECTION : Function_DECLARATION*/

#endif	/* DIPLOMA_H */



