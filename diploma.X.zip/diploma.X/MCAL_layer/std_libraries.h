/* 
 * File:   std_libraries.h
 * Author: Ahmed Donia
 *
 * Created on September 27, 2023, 4:54 PM
 */

#ifndef STD_LIBRARIES_H
#define	STD_LIBRARIES_H

/* SECTION : Includes*/

#include <stdio.h>
#include <stdlib.h>
#include<string.h>


/* SECTION : MACRO_Declaration*/

/* SECTION : MACRO_function_Declaration*/

/* SECTION : DATA_TYPES_DECLARATION*/


/* SECTION : Function_DECLARATION*/

#endif	/* STD_LIBRARIES_H */

