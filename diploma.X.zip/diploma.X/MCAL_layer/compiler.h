/* 
 * File:   compiler.h
 * Author: Ahmed Donia
 *
 * Created on September 27, 2023, 4:56 PM
 */

#ifndef COMPILER_H
#define	COMPILER_H
/* SECTION : Includes*/

/* SECTION : MACRO_Declaration*/

/* SECTION : MACRO_function_Declaration*/

/* SECTION : DATA_TYPES_DECLARATION*/


/* SECTION : Function_DECLARATION*/


#endif	/* COMPILER_H */

