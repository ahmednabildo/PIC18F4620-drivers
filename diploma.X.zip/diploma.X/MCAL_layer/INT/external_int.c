#include "external_int.h"

static void (*INT0_interruprt_handler)(void)= NULL;
static void (*INT1_interruprt_handler)(void)= NULL;
static void (*INT2_interruprt_handler)(void)= NULL;

static std_ReturnType INT0_set_interrupt_handler(void (*INT_interruprt_handler)(void));
static std_ReturnType INT1_set_interrupt_handler(void (*INT_interruprt_handler)(void));
static std_ReturnType INT2_set_interrupt_handler(void (*INT_interruprt_handler)(void));
static std_ReturnType INTX_set_interrupt_handler(const INTX_t *int_obj);

static std_ReturnType INTX_ENABLE (const INTX_t *int_obj);
static std_ReturnType INTX_DISABLE (const INTX_t *int_obj);
static std_ReturnType INTX_PRIORITY_INIT (const INTX_t *int_obj);
static std_ReturnType INTX_EDGE_INIT (const INTX_t *int_obj);
static std_ReturnType INTX_PIN_INIT (const INTX_t *int_obj);
static std_ReturnType INTX_Clear_Flag (const INTX_t *int_obj);

std_ReturnType INT_INTX_INIT(const INTX_t *int_obj)
{
    std_ReturnType ret = E_OK;
    if(NULL==int_obj)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        INTX_DISABLE(int_obj);
        INTX_Clear_Flag(int_obj);
        INTX_EDGE_INIT(int_obj);
        INTX_PRIORITY_INIT(int_obj);
        INTX_PIN_INIT(int_obj);
        INTX_set_interrupt_handler(int_obj); 
        INTX_ENABLE(int_obj);
        
    }
    return ret;
}
std_ReturnType INT_INTX_DE_INIT(const INTX_t *int_obj)
{
    std_ReturnType ret = E_OK;
    if(NULL==int_obj)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        
        INTX_DISABLE(int_obj);
    }
    return ret;
}

std_ReturnType INT_RBX_INIT(const RBX_t *int_obj)
{
    std_ReturnType ret = E_OK;
    if(NULL==int_obj)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        
        
    }
    return ret;
}
std_ReturnType INT_RBX_DE_INIT(const RBX_t *int_obj)
{
    std_ReturnType ret = E_OK;
    if(NULL==int_obj)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        
        
    }
    return ret;
}


static std_ReturnType INTX_ENABLE (const INTX_t *int_obj)
{
    std_ReturnType ret = E_OK;
    if(NULL==int_obj)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        switch (int_obj->src)
        {
        case INT_EXTERNAL_INT0:
        EXT_INT0_EN();
         ret = E_OK;
        break;
        case INT_EXTERNAL_INT1:
        EXT_INT1_EN();
         ret = E_OK;
        break;
        case INT_EXTERNAL_INT2:
        EXT_INT2_EN();
         ret = E_OK;
        break;
        default :
        ret=E_NOT_OK ;
        }


        
    }
    return ret;
}

static std_ReturnType INTX_DISABLE (const INTX_t *int_obj)
{
    std_ReturnType ret = E_OK;
    if(NULL==int_obj)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        switch (int_obj->src)
        {
        case INT_EXTERNAL_INT0:
        EXT_INT0_DIS();
         ret = E_OK;
        break;
        case INT_EXTERNAL_INT1:
        EXT_INT1_DIS();
         ret = E_OK;
        break;
        case INT_EXTERNAL_INT2:
        EXT_INT2_DIS();
         ret = E_OK;
        break;
        default :
        ret=E_NOT_OK ;
        }

        
    }
    return ret;
}

#if INT_Priority_Levels_EN==INT_Feature_EN
static std_ReturnType INTX_PRIORITY_INIT (const INTX_t *int_obj)
{
    std_ReturnType ret = E_OK;
    if(NULL==int_obj)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        switch (int_obj->src)
        {
        case INT_EXTERNAL_INT1:
        if (INT_HIGH_PRIORITY == int_obj->priority)
        {
            EXT_INT1_HIGH_PRIORITY_SET();
            ret = E_OK;
        }
        else if (INT_LOW_PRIORITY == int_obj->priority)
        {
            EXT_INT1_LOW_PRIORITY_SET();
            ret = E_OK;
        }
        else
        {

        }
        break;

        case INT_EXTERNAL_INT2:
        if (INT_HIGH_PRIORITY == int_obj->priority)
        {
            EXT_INT2_HIGH_PRIORITY_SET();
            ret = E_OK;
        }
        else if (INT_LOW_PRIORITY == int_obj->priority)
        {
            EXT_INT2_LOW_PRIORITY_SET();
            ret = E_OK;
        }
        else
        {

        }
        break;

        default :
        ret=E_NOT_OK ;
        }
    return ret;
    }
}
#endif

static std_ReturnType INTX_EDGE_INIT (const INTX_t *int_obj)
{
    std_ReturnType ret = E_OK;
    if(NULL==int_obj)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        switch (int_obj->src)
        {

        case INT_EXTERNAL_INT0:
        if (INT_FALLING == int_obj->edge)
        {
            EXT_INT0_Falling();
            ret = E_OK;
        }
        else if (INT_RISING == int_obj->edge)
        {
            EXT_INT0_Rising();
            ret = E_OK;
        }
        else
        {

        }
        break;
        
        case INT_EXTERNAL_INT1:
                if (INT_FALLING == int_obj->edge)
        {
            EXT_INT1_Falling();
            ret = E_OK;
        }
        else if (INT_RISING == int_obj->edge)
        {
            EXT_INT1_Rising();
            ret = E_OK;
        }
        else
        {

        }
        break;

        case INT_EXTERNAL_INT2:
                if (INT_FALLING == int_obj->edge)
        {
            EXT_INT2_Falling();
            ret = E_OK;
        }
        else if (INT_RISING == int_obj->edge)
        {
            EXT_INT2_Rising();
            ret = E_OK;
        }
        else
        {

        }
        break;

        default :
        ret=E_NOT_OK ;
        }
        
    }
    return ret;
}
static std_ReturnType INTX_PIN_INIT (const INTX_t *int_obj)
{
    std_ReturnType ret = E_OK;
    if(NULL==int_obj)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        gpio_pin_direction_initialize(&(int_obj->mcu_pin));
        gpio_pin_write_logic(&(int_obj->mcu_pin), int_obj->mcu_pin.logic);
        
        
    }
    return ret;
}
static std_ReturnType INTX_Clear_Flag (const INTX_t *int_obj)
{
    std_ReturnType ret = E_OK;
    if(NULL==int_obj)
    {
        ret=E_NOT_OK ;
    }
    else
    {

        switch (int_obj->src)
        {
        case INT_EXTERNAL_INT0:
        EXT_INT0_FLAG_CLEAR();
         ret = E_OK;
        break;
        case INT_EXTERNAL_INT1:
        EXT_INT1_FLAG_CLEAR();
         ret = E_OK;
        break;
        case INT_EXTERNAL_INT2:
        EXT_INT2_FLAG_CLEAR();
         ret = E_OK;
        break;
        default :
        ret=E_NOT_OK ;
        }
        
    }
    return ret;
}


static std_ReturnType INT0_set_interrupt_handler(void (*INT_interruprt_handler)(void))
{
    std_ReturnType ret = E_OK;
    if(NULL==INT_interruprt_handler)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        INT_interruprt_handler = INT0_interruprt_handler;
    }
    return ret;
}
static std_ReturnType INT1_set_interrupt_handler(void (*INT_interruprt_handler)(void))
{
    std_ReturnType ret = E_OK;
    if(NULL==INT_interruprt_handler)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        
        INT_interruprt_handler = INT1_interruprt_handler;
    }
    return ret;
}
static std_ReturnType INT2_set_interrupt_handler(void (*INT_interruprt_handler)(void))
{
    std_ReturnType ret = E_OK;
    if(NULL==INT_interruprt_handler)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        
        INT_interruprt_handler = INT2_interruprt_handler;
    }
    return ret;
}
static std_ReturnType INTX_set_interrupt_handler(const INTX_t *int_obj)
{
    std_ReturnType ret = E_OK;
    if(NULL==int_obj)
    {
        ret=E_NOT_OK ;
    }
    else
    {

        switch (int_obj->src)
        {
        case INT_EXTERNAL_INT0:
        INT0_set_interrupt_handler(int_obj->EXT_INT_HANDLER);
         ret = E_OK;
        break;
        case INT_EXTERNAL_INT1:
        INT1_set_interrupt_handler(int_obj->EXT_INT_HANDLER);
         ret = E_OK;
        break;
        case INT_EXTERNAL_INT2:
        INT2_set_interrupt_handler(int_obj->EXT_INT_HANDLER);
         ret = E_OK;
        break;
        default :
        ret=E_NOT_OK ;
        }
        
    }
    return ret;
}