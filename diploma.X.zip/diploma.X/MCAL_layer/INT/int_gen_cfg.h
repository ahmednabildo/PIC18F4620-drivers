/* 
 * File:   int_gen_cfg.h
 * Author: ahmed
 *
 * Created on November 9, 2023, 5:55 PM
 */

#ifndef INT_GEN_CFG_H
#define	INT_GEN_CFG_H

#define INT_Feature_EN 1
#define INT_Priority_Levels_EN      INT_Feature_EN
#define INT_External_INTx_EN        INT_Feature_EN
#define INT_External_Onchange_EN    INT_Feature_EN 

#endif	/* INT_GEN_CFG_H */

