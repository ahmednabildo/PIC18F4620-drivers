/* 
 * File:   newfile.h
 * Author: ahmed
 *
 * Created on November 9, 2023, 7:40 PM
 */

#ifndef NEWFILE_H
#define	NEWFILE_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* NEWFILE_H */

