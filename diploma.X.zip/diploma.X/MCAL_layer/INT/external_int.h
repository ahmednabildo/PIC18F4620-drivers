/* 
 * File:   external_int.h
 * Author: ahmed
 *
 * Created on November 9, 2023, 3:45 PM
 */

#ifndef EXTERNAL_INT_H
#define	EXTERNAL_INT_H


/* SECTION : Includes*/
#include "int_config.h"

/* SECTION : MACRO_Declaration*/



/* SECTION : MACRO_function_Declaration*/
#if  INT_External_INTx_EN==INT_Feature_EN
//INT0
#define EXT_INT0_EN()           (INTCONbits.INT0IE = 1)
#define EXT_INT0_DIS()          (INTCONbits.INT0IE = 0)
#define EXT_INT0_FLAG_CLEAR()   (INTCONbits.INT0IF = 0)
#define EXT_INT0_Rising()       (INTCON2bits.INTEDG0 = 1)
#define EXT_INT0_Falling()      (INTCON2bits.INTEDG0 = 0)

//INT1
#define EXT_INT1_EN()           (INTCON3bits.INT1IE = 1)
#define EXT_INT1_DIS()          (INTCON3bits.INT1IE = 0)
#define EXT_INT1_FLAG_CLEAR()   (INTCON3bits.INT1IF = 0)
#define EXT_INT1_Rising()       (INTCON2bits.INTEDG1 = 1)
#define EXT_INT1_Falling()      (INTCON2bits.INTEDG1 = 0)

//INT2
#define EXT_INT2_EN()           (INTCON3bits.INT2IE = 1)
#define EXT_INT2_DIS()          (INTCON3bits.INT2IE = 0)
#define EXT_INT2_FLAG_CLEAR()   (INTCON3bits.INT2IF = 0)
#define EXT_INT2_Rising()       (INTCON2bits.INTEDG2 = 1)
#define EXT_INT2_Falling()      (INTCON2bits.INTEDG2 = 0)

#if INT_Priority_Levels_EN==INT_Feature_EN

#define EXT_INT1_HIGH_PRIORITY_SET()            (INTCON3bits.INT1IP = 1)
#define EXT_INT1_LOW_PRIORITY_SET()             (INTCON3bits.INT1IP = 0)

#define EXT_INT2_HIGH_PRIORITY_SET()            (INTCON3bits.INT2IP = 1)
#define EXT_INT2_LOW_PRIORITY_SET()             (INTCON3bits.INT2IP = 0)
#endif

#endif

#if  INT_External_Onchange_EN==INT_Feature_EN

#define EXT_RBX_EN()           (INTCONbits.RBIE = 1)
#define EXT_RBX_DIS()          (INTCONbits.RBIE = 0)
#define EXT_RBX_FLAG_CLEAR()   (INTCONbits.RBIF = 0)

#if INT_Priority_Levels_EN==INT_Feature_EN

#define EXT_RBX_HIGH_PRIORITY()         (INTCONbits.RBIP = 1)
#define EXT_RBX_LOW_PRIORITY()          (INTCONbits.RBIP = 0)
#endif
#endif


/* SECTION : DATA_TYPES_DECLARATION*/

typedef enum 
{
    INT_FALLING =0,
    INT_RISING
}INTX_EDGE;

typedef enum 
{
    INT_EXTERNAL_INT0=0,
    INT_EXTERNAL_INT1,
    INT_EXTERNAL_INT2,
}INTX_SRC;
typedef struct 
{
    void (*EXT_INT_HANDLER)(void);
    pin_config_t mcu_pin;
    INTX_EDGE edge;
    INTX_SRC src;
    INT_PRIORITY_cfg priority;
}INTX_t;

typedef struct 
{
    void (*EXT_INT_HANDLER)(void);
    pin_config_t mcu_pin;
    INT_PRIORITY_cfg priority;
}RBX_t;


/* SECTION : Function_DECLARATION*/


std_ReturnType INT_INTX_INIT(const INTX_t *int_obj);
std_ReturnType INT_INTX_DE_INIT(const INTX_t *int_obj);

std_ReturnType INT_RBX_INIT(const RBX_t *int_obj);
std_ReturnType INT_RBX_DE_INIT(const RBX_t *int_obj);


#endif	/* EXTERNAL_INT_H */

