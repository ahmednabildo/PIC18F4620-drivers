/* 
 * File:   int_manager.h
 * Author: ahmed
 *
 * Created on November 9, 2023, 3:48 PM
 */

#ifndef INT_MANAGER_H
#define	INT_MANAGER_H


/* SECTION : Includes*/

#include "int_config.h"
/* SECTION : MACRO_Declaration*/

/* SECTION : MACRO_function_Declaration*/

/* SECTION : DATA_TYPES_DECLARATION*/


/* SECTION : Function_DECLARATION*/

#endif	/* INT_MANAGER_H */

