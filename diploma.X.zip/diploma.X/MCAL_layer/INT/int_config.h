/* 
 * File:   int_config.h
 * Author: ahmed
 *
 * Created on November 9, 2023, 3:44 PM
 */

#ifndef INT_CONFIG_H
#define	INT_CONFIG_H

/* SECTION : Includes*/
#include"C:\Program Files\Microchip\MPLABX\v6.15\packs\Microchip\PIC18Fxxxx_DFP\1.4.151\xc8\pic\include\proc\pic18f4620.h"
#include"../macl_std_types.h"
#include "int_gen_cfg.h"
#include"../GPIO/hal_gpio.h"

/* SECTION : MACRO_Declaration*/
#define INT_Enable       1
#define INT_Disable      0
#define INT_Occur        1
#define INT_Not_Occur    0
#define INT_priority_en  1
#define INT_priority_dis 0
/* SECTION : MACRO_function_Declaration*/
#if INT_Priority_Levels_EN==INT_Feature_EN

 #define INT_priority_EN()     (RCONbits.IPEN = 1)
 #define INT_priority_DIS()    (RCONbits.IPEN = 0)

 #define INT_Global_HIGH_EN()  (INTCONbits.GIEH = 1)
 #define INT_Global_HIGH_DIS() (INTCONbits.GIEH = 0)

#define INT_Global_LOW_EN()    (INTCONbits.GIEL = 1)
 #define INT_Global_LOW_DIS()  (INTCONbits.GIEL = 0)

#else
 #define INT_Prephiral_EN()    (INTCONbits.PEIE = 1)
 #define INT_Prephiral_DIS()   (INTCONbits.PEIE = 0)
 #endif
/* SECTION : DATA_TYPES_DECLARATION*/
typedef enum 
{
    INT_LOW_PRIORITY =0,
    INT_HIGH_PRIORITY
}INT_PRIORITY_cfg;

/* SECTION : Function_DECLARATION*/

#endif	/* INT_CONFIG_H */

