/* 
 * File:   internal_int.h
 * Author: ahmed
 *
 * Created on November 9, 2023, 3:44 PM
 */

#ifndef INTERNAL_INT_H
#define	INTERNAL_INT_H

#include "int_config.h"
/* SECTION : Includes*/


/* SECTION : MACRO_Declaration*/

/* SECTION : MACRO_function_Declaration*/

/* SECTION : DATA_TYPES_DECLARATION*/


/* SECTION : Function_DECLARATION*/

#endif	/* INTERNAL_INT_H */

