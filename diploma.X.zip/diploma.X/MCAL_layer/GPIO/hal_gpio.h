/* 
 * File:   hal_gpio.h
 * Author: Ahmed Donia
 *
 * Created on September 27, 2023, 4:46 PM
 */

#ifndef HAL_GPIO_H
#define	HAL_GPIO_H
/* SECTION : Includes*/
#include"C:\Program Files\Microchip\MPLABX\v6.15\packs\Microchip\PIC18Fxxxx_DFP\1.4.151\xc8\pic\include\proc\pic18f4620.h"
#include"../macl_std_types.h"
#include"hal_gpio_cfg.h"
#include "../../device_config.h"


/* SECTION : MACRO_Declaration*/
#define BIT_MASK (uint8)1
#define PORT_PIN_MAX_NUMBER 7
#define PORT_MAX_NUMBER 4
#define PORT_PIN_CONFIG CONFIG_ENABLE
#define PORT_CONFIG CONFIG_ENABLE
#define PORT_OUTPUT (uint8)0x00
#define PORT_INPUT (uint8)0xFF
#define PORT_LOW (uint8)0x00
#define PORT_HIGH (uint8)0xFF
#define _XTAL_FREQ 8000000UL




/* SECTION : MACRO_function_Declaration*/
#define HWREG8(_x)  (*((volatile uint8 *)(_x)))

#define SET_BIT(PORT,BIT_NO)    (PORT|=(BIT_MASK<<BIT_NO))
#define CLEAR_BIT(PORT,BIT_NO)  (PORT&= ~(BIT_MASK<<BIT_NO))
#define TOG_BIT(PORT,BIT_NO)    (PORT^=(BIT_MASK<<BIT_NO))
#define READ_BIT(PORT,BIT_NO)   ((PORT >> BIT_NO) & BIT_MASK)

/* SECTION : DATA_TYPES_DECLARATION*/
typedef enum
{
    LOW=0,
    HIGH
}logic_t;

typedef enum
{
    OUTPUT=0,
    INPUT
}direction_t;





typedef enum
{
    PIN0=0,
    PIN1,
    PIN2,
    PIN3,
    PIN4,
    PIN5,
    PIN6,
    PIN7
    
}pin_index_t;

typedef enum
{
    PORTA_INDEX=0,
    PORTB_INDEX,
    PORTC_INDEX,
    PORTD_INDEX,
    PORTE_INDEX
}port_index_t;

typedef struct 
{
    uint8 port : 3;
    uint8 pin : 3;
    uint8 direction : 1;
    uint8 logic : 1;
    
}pin_config_t;


/* SECTION : Function_DECLARATION*/
std_ReturnType gpio_pin_direction_initialize(const pin_config_t * _pin_config);
std_ReturnType gpio_pin_get_direction_status(const pin_config_t * _pin_config , direction_t * direction_status);
std_ReturnType gpio_pin_write_logic(const pin_config_t * _pin_config , logic_t logic);
std_ReturnType gpio_pin_read_logic(const pin_config_t * _pin_config , logic_t *logic);
std_ReturnType gpio_pin_toggle_logic(const pin_config_t * _pin_config);

std_ReturnType gpio_port_direction_initialize( port_index_t port, uint8 direction);
std_ReturnType gpio_port_get_direction_status( port_index_t port , uint8 *direction_status);
std_ReturnType gpio_port_write_logic( port_index_t port , uint8 logic);
std_ReturnType gpio_port_read_logic( port_index_t port , uint8 *logic);
std_ReturnType gpio_port_toggle_logic( port_index_t port);
#endif	/* HAL_GPIO_H */

