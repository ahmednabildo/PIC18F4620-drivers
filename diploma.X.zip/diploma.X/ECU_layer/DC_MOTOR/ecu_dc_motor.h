/* 
 * File:   ecu_dc_motor.h
 * Author: Ahmed Donia
 *
 * Created on October 9, 2023, 5:11 PM
 */

#ifndef ECU_DC_MOTOR_H
#define	ECU_DC_MOTOR_H
/* SECTION : Includes*/
#include"../../MCAL_layer/GPIO/hal_gpio.h"
#include"ecu_dc_motor_cfg.h"


/* SECTION : MACRO_Declaration*/
#define DC_MOTOR_STATUS_ON     (uint8)0x01
#define DC_MOTOR_STATUS_OFF    (uint8)0x00

#define DC_MOTOR_PIN0    (uint8)0x00
#define DC_MOTOR_PIN1    (uint8)0x01

/* SECTION : MACRO_function_Declaration*/

/* SECTION : DATA_TYPES_DECLARATION*/
typedef struct 
{
    pin_config_t dc_motor[2];
    
}dc_motor_t;

/* SECTION : Function_DECLARATION*/
std_ReturnType dc_motor_initialize (const dc_motor_t * dc_motor);
std_ReturnType dc_motor_move_right (const dc_motor_t * dc_motor);
std_ReturnType dc_motor_move_left (const dc_motor_t * dc_motor);
std_ReturnType dc_motor_stop(const dc_motor_t * dc_motor);

#endif	/* ECU_DC_MOTOR_H */

