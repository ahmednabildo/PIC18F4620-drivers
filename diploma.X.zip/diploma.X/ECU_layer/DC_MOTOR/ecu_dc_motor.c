#include"ecu_dc_motor.h"


std_ReturnType dc_motor_initialize (const dc_motor_t * dc_motor)
{
    std_ReturnType ret = E_OK;

    if(NULL==dc_motor)
    {
        ret=E_NOT_OK ;
    }
    else
    {
            
        gpio_pin_direction_initialize(& (dc_motor->dc_motor[0])) ;
        gpio_pin_direction_initialize(& (dc_motor->dc_motor[1])) ;
        
    }
    return ret;
}
std_ReturnType dc_motor_move_right (const dc_motor_t * dc_motor)
{
    std_ReturnType ret = E_OK;

    if(NULL==dc_motor)
    {
        ret=E_NOT_OK ;
    }
    else
    {
            
        gpio_pin_write_logic(& (dc_motor->dc_motor[0]) , HIGH);   
        gpio_pin_write_logic(& (dc_motor->dc_motor[1]) , LOW);   
        
    }
    return ret;
}
std_ReturnType dc_motor_move_left (const dc_motor_t * dc_motor)
{
    std_ReturnType ret = E_OK;

    if(NULL==dc_motor)
    {
        ret=E_NOT_OK ;
    }
    else
    {
            
        gpio_pin_write_logic(& (dc_motor->dc_motor[1]) , HIGH);   
        gpio_pin_write_logic(& (dc_motor->dc_motor[0]) , LOW);   
        
    }
    return ret;
}
std_ReturnType dc_motor_stop(const dc_motor_t * dc_motor)
{
    std_ReturnType ret = E_OK;

    if(NULL==dc_motor)
    {
        ret=E_NOT_OK ;
    }
    else
    {
            
        gpio_pin_write_logic(& (dc_motor->dc_motor[0]) , LOW);   
        gpio_pin_write_logic(& (dc_motor->dc_motor[1]) , LOW);   
        
    }
    return ret;
}
