/* 
 * File:   ecu_dc_motor_cfg.h
 * Author: Ahmed Donia
 *
 * Created on October 9, 2023, 5:12 PM
 */

#ifndef ECU_DC_MOTOR_CFG_H
#define	ECU_DC_MOTOR_CFG_H

/* SECTION : Includes*/


/* SECTION : MACRO_Declaration*/

/* SECTION : MACRO_function_Declaration*/

/* SECTION : DATA_TYPES_DECLARATION*/


/* SECTION : Function_DECLARATION*/

#endif	/* ECU_DC_MOTOR_CFG_H */

