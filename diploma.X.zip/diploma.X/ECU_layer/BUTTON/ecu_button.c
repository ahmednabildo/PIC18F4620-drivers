
#include "ecu_button.h"


std_ReturnType button_initialize(const button_t *btn)
{
    std_ReturnType ret = E_OK;

    if(NULL==btn)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        gpio_pin_direction_initialize(& (btn->button_pin)) ;
    }
    return ret;
}




std_ReturnType button_read_state(const button_t *btn, button_state_t *btn_state)
{
    std_ReturnType ret = E_NOT_OK;

    if(NULL==btn || NULL==btn_state)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        logic_t read = LOW;
        
        gpio_pin_read_logic( &(btn->button_pin) ,& read);
        if(BUTTON_ACTIVE_HIGH == btn->button_connection )
        {
            if(LOW == read)
            {
                * btn_state = BUTTON_RELEASED;
            }
            else
            {
                * btn_state = BUTTON_PRESSED;
            }
        }
        else if (BUTTON_ACTIVE_LOW == btn->button_connection)
        {
            if(HIGH == read)
            {
                * btn_state = BUTTON_RELEASED;
            }
            else
            {
                * btn_state = BUTTON_PRESSED;
            }
        }
        else
        {
            
        }
        ret = E_OK;
    }
    return ret;
}
