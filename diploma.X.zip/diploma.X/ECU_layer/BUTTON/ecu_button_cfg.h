/* 
 * File:   ecu_button_cfg.h
 * Author: Ahmed Donia
 *
 * Created on October 8, 2023, 12:08 PM
 */

#ifndef ECU_BUTTON_CFG_H
#define	ECU_BUTTON_CFG_H



#endif	/* ECU_BUTTON_CFG_H */

