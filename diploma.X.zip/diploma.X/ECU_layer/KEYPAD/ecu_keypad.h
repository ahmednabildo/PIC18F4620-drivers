/* 
 * File:   ecu_keypad.h
 * Author: Ahmed Donia
 *
 * Created on October 10, 2023, 12:42 PM
 */

#ifndef ECU_KEYPAD_H
#define	ECU_KEYPAD_H
/* SECTION : Includes*/
#include"ecu_keypad_cfg.h"
#include "../../MCAL_layer/GPIO/hal_gpio.h"



/* SECTION : MACRO_Declaration*/
#define ECU_KEYPAD_ROWS 4
#define ECU_KEYPAD_COL  4

/* SECTION : MACRO_function_Declaration*/

/* SECTION : DATA_TYPES_DECLARATION*/
typedef struct
{
    pin_config_t keypad_row_pins [ECU_KEYPAD_ROWS];
    pin_config_t keypad_col_pins [ECU_KEYPAD_COL];
}keypad_t;

/* SECTION : Function_DECLARATION*/
std_ReturnType keypad_initialize(const keypad_t * keypad_obj);
std_ReturnType keypad_get_value(const keypad_t * keypad_obj , uint8 *value);
#endif	/* ECU_KEYPAD_H */

