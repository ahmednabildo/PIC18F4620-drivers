#include"ecu_keypad.h"

static const uint8 btn_values [ECU_KEYPAD_ROWS][ECU_KEYPAD_COL] = {'7','8','9','/',
                                                                   '4','5','6','*',
                                                                   '1','2','3','-',
                                                                   'O','0','=','+'};

std_ReturnType keypad_initialize(const keypad_t * keypad_obj)
{
    std_ReturnType ret = E_OK;
    if(NULL==keypad_obj)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        for(uint8 i=0;i<ECU_KEYPAD_ROWS;i++)
        {
            gpio_pin_direction_initialize(&(keypad_obj->keypad_row_pins[i]));
        }
        
        for(uint8 i=0;i<ECU_KEYPAD_COL;i++)
        {
            gpio_pin_direction_initialize(&(keypad_obj->keypad_col_pins[i]));
        }
       
        
    }
    return ret;
}


std_ReturnType keypad_get_value(const keypad_t * keypad_obj , uint8 *value)
{
    std_ReturnType ret = E_OK;
    if(NULL==keypad_obj || NULL == value)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        uint8 col_logic = LOW;
        for(uint8 i=0;i<ECU_KEYPAD_ROWS;i++)
        {
            for(uint8 j=0;j<ECU_KEYPAD_ROWS;j++)
            {
                gpio_pin_write_logic(&(keypad_obj->keypad_row_pins[i]) , LOW);
            }
            gpio_pin_write_logic(&(keypad_obj->keypad_row_pins[i]) , HIGH);
            __delay_ms(1000);
            
            for(uint8 j=0;i<ECU_KEYPAD_COL;j++)
            {
                gpio_pin_read_logic(&(keypad_obj->keypad_col_pins[i]) , &col_logic);
                
                if(col_logic == HIGH)
                {
                    *value = btn_values [i] [j];
                }
            }
        }
    }
    return ret;
}
