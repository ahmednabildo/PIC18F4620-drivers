#include"ecu_7_seg.h"

std_ReturnType _7_seg_init(const seg_t * seg)
{
    std_ReturnType ret = E_OK;

    if(NULL==seg)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        gpio_pin_direction_initialize(&(seg->seg_pins[SEG_PIN0])) ;
        gpio_pin_direction_initialize(&(seg->seg_pins[SEG_PIN1])) ;
        gpio_pin_direction_initialize(&(seg->seg_pins[SEG_PIN2])) ;
        gpio_pin_direction_initialize(&(seg->seg_pins[SEG_PIN3])) ;
    }
    return ret;
}
std_ReturnType _7_seg_iwrite_number(const seg_t * seg , uint8 number)
{
    std_ReturnType ret = E_OK;

    if(NULL==seg || number > 9)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        gpio_pin_write_logic(&(seg->seg_pins[SEG_PIN0]),(number >> SEG_PIN0) & 0x01) ;
        gpio_pin_write_logic(&(seg->seg_pins[SEG_PIN1]),(number >> SEG_PIN1) & 0x01) ;
        gpio_pin_write_logic(&(seg->seg_pins[SEG_PIN2]),(number >> SEG_PIN2) & 0x01) ;
        gpio_pin_write_logic(&(seg->seg_pins[SEG_PIN3]),(number >> SEG_PIN3) & 0x01) ;
    }
    return ret;
}
