/* 
 * File:   ecu_7_seg_cfg.h
 * Author: Ahmed Donia
 *
 * Created on October 9, 2023, 9:41 PM
 */

#ifndef ECU_7_SEG_CFG_H
#define	ECU_7_SEG_CFG_H


#endif	/* ECU_7_SEG_CFG_H */

