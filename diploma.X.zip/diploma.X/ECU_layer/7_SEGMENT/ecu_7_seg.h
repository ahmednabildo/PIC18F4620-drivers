/* 
 * File:   ecu_7_seg.h
 * Author: Ahmed Donia
 *
 * Created on October 9, 2023, 9:41 PM
 */

#ifndef ECU_7_SEG_H
#define	ECU_7_SEG_H

/* SECTION : Includes*/
#include"../../MCAL_layer/GPIO/hal_gpio.h"
#include"ecu_7_seg_cfg.h"


/* SECTION : MACRO_Declaration*/
#define SEG_PIN0 0
#define SEG_PIN1 1
#define SEG_PIN2 2
#define SEG_PIN3 3
/* SECTION : MACRO_function_Declaration*/

/* SECTION : DATA_TYPES_DECLARATION*/
typedef enum
{
    SEG_COM_ANO,
    SEG_COM_CAT
}seg_type_t;

typedef struct
{
    pin_config_t seg_pins[4];
    seg_type_t seg_type;
    
}seg_t;
/* SECTION : Function_DECLARATION*/
std_ReturnType _7_seg_init(const seg_t * seg);
std_ReturnType _7_seg_iwrite_number(const seg_t * seg , uint8 number);

#endif	/* ECU_7_SEG_H */

