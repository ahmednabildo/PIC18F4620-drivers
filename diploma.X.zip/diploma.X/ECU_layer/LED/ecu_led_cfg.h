/* 
 * File:   ecu_led_cfg.h
 * Author: Ahmed Donia
 *
 * Created on October 7, 2023, 2:49 PM
 */

#ifndef ECU_LED_CFG_H
#define	ECU_LED_CFG_H

/* SECTION : Includes*/

/* SECTION : MACRO_Declaration*/

/* SECTION : MACRO_function_Declaration*/

/* SECTION : DATA_TYPES_DECLARATION*/

/* SECTION : Function_DECLARATION*/

#endif	/* ECU_LED_CFG_H */

