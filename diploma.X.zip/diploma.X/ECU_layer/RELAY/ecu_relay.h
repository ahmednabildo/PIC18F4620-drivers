/* 
 * File:   ecu_relay.h
 * Author: Ahmed Donia
 *
 * Created on October 9, 2023, 3:50 PM
 */

#ifndef ECU_RELAY_H
#define	ECU_RELAY_H
/* SECTION : Includes*/
#include"../../MCAL_layer/GPIO/hal_gpio.h"
#include"ecu_relay_cfg.h"


/* SECTION : MACRO_Declaration*/
#define RELAY_STATUS_ON     (uint8)0x01
#define RELAY_STATUS_OFF    (uint8)0x00

/* SECTION : MACRO_function_Declaration*/

/* SECTION : DATA_TYPES_DECLARATION*/
typedef struct 
{
    uint8 relay_port : 4;
    uint8 relay_pin : 3;
    uint8 relay_status : 1;
}relay_t;

/* SECTION : Function_DECLARATION*/
std_ReturnType relay_initialize (const relay_t * relay );
std_ReturnType relay_turn_on (const relay_t * relay );
std_ReturnType relay_turn_off (const relay_t * relay );



#endif	/* ECU_RELAY_H */

