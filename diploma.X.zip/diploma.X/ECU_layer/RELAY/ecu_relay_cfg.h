/* 
 * File:   ecu_relay_cfg.h
 * Author: Ahmed Donia
 *
 * Created on October 9, 2023, 3:50 PM
 */

#ifndef ECU_RELAY_CFG_H
#define	ECU_RELAY_CFG_H

/* SECTION : Includes*/

/* SECTION : MACRO_Declaration*/

/* SECTION : MACRO_function_Declaration*/

/* SECTION : DATA_TYPES_DECLARATION*/

/* SECTION : Function_DECLARATION*/

#endif	/* ECU_RELAY_CFG_H */

