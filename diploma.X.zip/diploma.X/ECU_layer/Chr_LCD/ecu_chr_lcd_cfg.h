/* 
 * File:   ecu_chr_lcd_cfg.h
 * Author: Ahmed Donia
 *
 * Created on October 11, 2023, 8:55 PM
 */

#ifndef ECU_CHR_LCD_CFG_H
#define	ECU_CHR_LCD_CFG_H



#endif	/* ECU_CHR_LCD_CFG_H */

