#include "ecu_chr_lcd.h"

/**************************************************************************4bits LCD**********************************************************************************************/
std_ReturnType lcd_4_bit_initialize(const chr_lcd_4_bits_t *lcd)
{
    std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        gpio_pin_direction_initialize(&(lcd->lcd_rs));
        gpio_pin_write_logic(&(lcd->lcd_rs) , lcd->lcd_rs.logic);
        
        gpio_pin_direction_initialize(&(lcd->lcd_en));
        gpio_pin_write_logic(&(lcd->lcd_en ), lcd->lcd_en.logic);
        for(uint8 i =0;i<4;i++)
        {
            gpio_pin_direction_initialize(&(lcd->lcd_data[i]));
            gpio_pin_write_logic(&(lcd->lcd_data[i]) , lcd->lcd_data[i].logic);
        }
        __delay_ms(20);
        lcd_4_bit_send_command(lcd , _LCD_8BIT_MODE_2_LINE);
        __delay_ms(5);
        lcd_4_bit_send_command(lcd , _LCD_8BIT_MODE_2_LINE);
        __delay_us(150);
        lcd_4_bit_send_command(lcd , _LCD_8BIT_MODE_2_LINE);
        
        lcd_4_bit_send_command(lcd , _LCD_CLEAR);
        lcd_4_bit_send_command(lcd , _LCD_RETURN_HOME);
        lcd_4_bit_send_command(lcd , _LCD_ENTRY_MODE_INC_SHIFT_OFF);
        
        lcd_4_bit_send_command(lcd , _LCD_DISPLAY_ON_UNDERLINE_OFF_CURSOR_OFF);
        lcd_4_bit_send_command(lcd , _LCD_4BIT_MODE_2_LINE);
        lcd_4_bit_send_command(lcd , 0x80);
        
    }
    return ret;
}
std_ReturnType lcd_4_bit_send_command(const chr_lcd_4_bits_t *lcd , uint8 command)
{
    std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        gpio_pin_write_logic(&(lcd->lcd_rs) , LOW);
        lcd_send_4_bits(lcd , command >> 4);
        lcd_4bit_send_enable_signal(lcd);
        lcd_send_4_bits(lcd , command);
        lcd_4bit_send_enable_signal(lcd);
        
        
    }
    return ret;
}
std_ReturnType lcd_4_bit_send_char_data(const chr_lcd_4_bits_t *lcd , uint8 data)
{
    std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        gpio_pin_write_logic(&(lcd->lcd_rs) , HIGH);
        lcd_send_4_bits(lcd , data >> 4);
        lcd_4bit_send_enable_signal(lcd);
        lcd_send_4_bits(lcd , data);
        lcd_4bit_send_enable_signal(lcd);
        
        
    }
    return ret;
}
std_ReturnType lcd_4_bit_send_char_data_pos(const chr_lcd_4_bits_t *lcd , uint8 row, uint8 col, uint8 data)
{
    std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        lcd_4bit_set_cursor(lcd,  row,  col);
        lcd_4_bit_send_char_data(lcd , data);
        
    }
    return ret;
}
std_ReturnType lcd_4_bit_send_string(const chr_lcd_4_bits_t *lcd , uint8 * str)
{
        std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        while(*str)
        {
            lcd_4_bit_send_char_data(lcd , *str++);
            
        }
        
    }
    return ret;
}
std_ReturnType lcd_4_bit_send_str_data_pos(const chr_lcd_4_bits_t *lcd , uint8 row, uint8 col, uint8 * str)
{
        std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        lcd_4bit_set_cursor(lcd , row , col);
        lcd_4_bit_send_string(lcd , str);
        
    }
    return ret;
}
std_ReturnType lcd_4_bit_send_custom_char(const chr_lcd_4_bits_t *lcd , uint8 row, uint8 col, const uint8 chr[], uint8 mem_pos)
{
    std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        lcd_4_bit_send_command(lcd , (_LCD_CGRAM_START + 8*(mem_pos)));
        for(uint8 i =0; i<8 ; i++)
        {
            lcd_4_bit_send_char_data(lcd , chr[i]);
        }
        lcd_4_bit_send_char_data_pos(lcd , row , col , mem_pos);
        
    }
    return ret;
}










/**************************************************************************8bits LCD**********************************************************************************************/

std_ReturnType lcd_8_bit_initialize(const chr_lcd_8_bits_t *lcd)
{
        std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        gpio_pin_direction_initialize(&(lcd->lcd_rs));
        gpio_pin_write_logic(&(lcd->lcd_rs) , lcd->lcd_rs.logic);
        
        gpio_pin_direction_initialize(&(lcd->lcd_en));
        gpio_pin_write_logic(&(lcd->lcd_en ), lcd->lcd_en.logic);
        for(uint8 i =0;i<8;i++)
        {
            gpio_pin_direction_initialize(&(lcd->lcd_data[i]));
            gpio_pin_write_logic(&(lcd->lcd_data[i]) , lcd->lcd_data[i].logic);
        }
        __delay_ms(20);
        lcd_8_bit_send_command(lcd , _LCD_8BIT_MODE_2_LINE);
        __delay_ms(5);
        lcd_8_bit_send_command(lcd , _LCD_8BIT_MODE_2_LINE);
        __delay_us(150);
        lcd_8_bit_send_command(lcd , _LCD_8BIT_MODE_2_LINE);
        
        
        lcd_8_bit_send_command(lcd , _LCD_CLEAR);
        lcd_8_bit_send_command(lcd , _LCD_RETURN_HOME);
        lcd_8_bit_send_command(lcd , _LCD_ENTRY_MODE_INC_SHIFT_OFF);
        lcd_8_bit_send_command(lcd , _LCD_DISPLAY_ON_UNDERLINE_OFF_CURSOR_OFF);
        lcd_8_bit_send_command(lcd , _LCD_8BIT_MODE_2_LINE);
        lcd_8_bit_send_command(lcd , 0x80);
        
    }
    return ret;
}
std_ReturnType lcd_8_bit_send_command(const chr_lcd_8_bits_t *lcd , uint8 command)
{
        std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        gpio_pin_write_logic(&(lcd->lcd_rs) , LOW);
        
        for(uint8 i = 0; i < 8; i++)
        {
            gpio_pin_write_logic(&(lcd->lcd_data[i] ), (command >> i) & (uint8)0x01);
            
        }

        lcd_8bit_send_enable_signal(lcd);
        
    }
    return ret;
}
std_ReturnType lcd_8_bit_send_char_data(const chr_lcd_8_bits_t *lcd , uint8 data)
{
        std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        gpio_pin_write_logic(&(lcd->lcd_rs) , HIGH);
        
        for(uint8 i = 0; i < 8; i++)
        {
            gpio_pin_write_logic(&(lcd->lcd_data[i]), (data >> i) & (uint8)0x01);
            
        }

        lcd_8bit_send_enable_signal(lcd);
        
    }
    return ret;
}
std_ReturnType lcd_8_bit_send_char_data_pos(const chr_lcd_8_bits_t *lcd , uint8 row, uint8 col, uint8 data)
{
        std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        lcd_8bit_set_cursor(lcd,  row,  col);
        lcd_8_bit_send_char_data(lcd , data);

        
    }
    return ret;
}
std_ReturnType lcd_8_bit_send_string(const chr_lcd_8_bits_t *lcd , uint8 * str)
{
        std_ReturnType ret = E_OK;
    if(NULL==lcd )
    {
        ret=E_NOT_OK ;
    }
    else
    {
        
        while(*str)
        {
            lcd_8_bit_send_char_data(lcd , *str++);
            
        }
    }
    return ret;
}
std_ReturnType lcd_8_bit_send_str_data_pos(const chr_lcd_8_bits_t *lcd , uint8 row, uint8 col, uint8 * str)
{
        std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        
        lcd_8bit_set_cursor(lcd , row , col);
        lcd_8_bit_send_string(lcd , str);
    }
    return ret;
}
std_ReturnType lcd_8_bit_send_custom_char(const chr_lcd_8_bits_t *lcd , uint8 row, uint8 col, const uint8 chr[], uint8 mem_pos)
{
        std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        lcd_8_bit_send_command(lcd , (_LCD_CGRAM_START + 8*(mem_pos)));
        for(uint8 i =0; i<8 ; i++)
        {
            lcd_8_bit_send_char_data(lcd , chr[i]);
        }
        lcd_8_bit_send_char_data_pos(lcd , row , col , mem_pos);
        
    }
    return ret;
}





/*******************************************************************************************************************************************************************************/
std_ReturnType convert_byte_to_string(uint8 value , uint8 *str)
{
    std_ReturnType ret = E_OK;
    if(NULL==str)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        memset(str , '\0' , 4);
        sprintf(str , "%i" , value);
        
    }
    return ret;
}
std_ReturnType convert_short_to_string(uint16 value , uint8 *str)
{
    std_ReturnType ret = E_OK;
    if(NULL==str)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        memset(str , '\0' , 6);
        sprintf(str , "%i" , value);
        
    }
    return ret;
}
std_ReturnType convert_int_to_string(uint32 value , uint8 *str)
{
    std_ReturnType ret = E_OK;
    if(NULL==str)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        memset(str , '\0' , 11);
        sprintf(str , "%i" , value);
        
    }
    return ret;
}


std_ReturnType lcd_send_4_bits(const chr_lcd_4_bits_t *lcd , uint8 command )
{
    std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        for(uint8 i = 0; i<4;i++)
        {
            gpio_pin_write_logic(&(lcd->lcd_data[i] ), (command >> i) & (uint8) 0x01);
        }
         
        
    }
    return ret;
}
std_ReturnType lcd_4bit_send_enable_signal(const chr_lcd_4_bits_t *lcd)
{
    std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        gpio_pin_write_logic(&(lcd->lcd_en), HIGH);
        __delay_us(5);
        gpio_pin_write_logic(&(lcd->lcd_en), LOW);
    }
    return ret;
}
std_ReturnType lcd_8bit_send_enable_signal(const chr_lcd_8_bits_t *lcd)
{
    std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        gpio_pin_write_logic(&(lcd->lcd_en), HIGH);
        __delay_us(5);
        gpio_pin_write_logic(&(lcd->lcd_en), LOW);
    }
    return ret;
}
std_ReturnType lcd_8bit_set_cursor(const chr_lcd_8_bits_t *lcd, uint8 row, uint8 col)
{
    std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        col--;
        switch (row)
        {
            case ROW1 : lcd_8_bit_send_command(lcd , 0x80 + col); break;
            case ROW2 : lcd_8_bit_send_command(lcd , 0xc0 + col); break;
            case ROW3 : lcd_8_bit_send_command(lcd , 0x94 + col); break;
            case ROW4 : lcd_8_bit_send_command(lcd , 0xd4 + col); break;
            default : ; 
        }
        
    }
    return ret;
}

std_ReturnType lcd_4bit_set_cursor(const chr_lcd_4_bits_t *lcd, uint8 row, uint8 col)
{
    std_ReturnType ret = E_OK;
    if(NULL==lcd)
    {
        ret=E_NOT_OK ;
    }
    else
    {
        col--;
        switch (row)
        {
            case ROW1 : lcd_4_bit_send_command(lcd , 0x80 + col); break;
            case ROW2 : lcd_4_bit_send_command(lcd , 0xc0 + col); break;
            case ROW3 : lcd_4_bit_send_command(lcd , 0x94 + col); break;
            case ROW4 : lcd_4_bit_send_command(lcd , 0xd4 + col); break;
            default : ; 
        }
        
    }
    return ret;
}
